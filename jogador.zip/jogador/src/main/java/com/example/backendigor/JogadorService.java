package com.example.backendigor;


import org.springframework.stereotype.Service;
import java.util.Random;
import java.util.Random;

@Service
public class JogadorService {

    public static String gerarjogador(String posicao, String clube){
        String nome[]= {"ronaldinho", "josue", "romario", "kaka", "neymar","luan"};
        String sobrenome[]= {"fenomeno", "silva", "souza", "nazario", "santos","pires"};
        int idade=25;

        Random random = new Random();
        int nomer = random.nextInt(nome.length);
        int sobrenomer = random.nextInt(sobrenome.length);
        int idade2 = random.nextInt(18,35);

        return "nome: "+nome[nomer]+" "+sobrenome[sobrenomer]+"\n ;idade: "+idade2+" anos \n ;Posição: "+posicao+ " ;clube: "+clube;

    }
}


