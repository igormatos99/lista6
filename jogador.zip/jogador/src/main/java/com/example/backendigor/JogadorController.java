package com.example.backendigor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JogadorController {
    @Autowired
    public JogadorService jogadorService;

    @GetMapping("/jogador/{clube}/{posicao}")
    public String jogador(@PathVariable String posicao, @PathVariable String clube) {
        return JogadorService.gerarjogador(posicao,clube);
    }

}
