package com.example.backendigor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendigorApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendigorApplication.class, args);
	}

}
